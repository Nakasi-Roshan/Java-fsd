package com.starhealth.customer.microservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.customer.microservice.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer>{

}
