package com.starhealth.customer.microservice.service;

import com.starhealth.customer.microservice.entity.Customer;
import com.starhealth.customer.microservice.vo.CustomerProductVo;

public interface CustomerService {
	
	public Customer addCustomer(Customer customer);
	public Customer getCustomerById(int customerId);
	public CustomerProductVo getCustomerWithProduct(int customerId);

}
