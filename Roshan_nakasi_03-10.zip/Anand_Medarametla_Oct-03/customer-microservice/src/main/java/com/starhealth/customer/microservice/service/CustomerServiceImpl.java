package com.starhealth.customer.microservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.starhealth.customer.microservice.entity.Customer;
import com.starhealth.customer.microservice.repo.CustomerRepo;
import com.starhealth.customer.microservice.vo.CustomerProductVo;
import com.starhealth.customer.microservice.vo.Product;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CustomerRepo customerRepo;

	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
	}

	@Override
	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return customerRepo.findById(customerId).orElse(new Customer());
	}

	@Override
	public CustomerProductVo getCustomerWithProduct(int customerId) {
		// TODO Auto-generated method stub
		Customer customer = getCustomerById(customerId);
		int productId = customer.getProductId();

		Product product = restTemplate.getForObject("http://localhost:8181/api/v1/product/get/"+ productId,Product.class);

		CustomerProductVo customerProductVo = new CustomerProductVo(customer, product);
		return customerProductVo;
		
		
	}
	

}
