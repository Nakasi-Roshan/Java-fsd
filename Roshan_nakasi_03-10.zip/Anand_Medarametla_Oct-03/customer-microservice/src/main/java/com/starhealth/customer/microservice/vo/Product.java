package com.starhealth.customer.microservice.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Product {
	
	int productId;

	String productName;

}
