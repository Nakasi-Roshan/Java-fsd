package com.starhealth.customer.microservice.vo;

import com.starhealth.customer.microservice.entity.Customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CustomerProductVo {
	
	private Customer customer;
	private Product product;
	

}
