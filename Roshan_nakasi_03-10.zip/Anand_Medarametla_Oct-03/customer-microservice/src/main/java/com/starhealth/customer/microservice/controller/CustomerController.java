package com.starhealth.customer.microservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.customer.microservice.entity.Customer;
import com.starhealth.customer.microservice.service.CustomerService;
import com.starhealth.customer.microservice.vo.CustomerProductVo;



@RestController
@RequestMapping("api/v1/customers")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	
	
		@PostMapping("/add")
		public  Customer addCustomer(@RequestBody Customer customer) {
			
			
			return customerService.addCustomer(customer);
			
		}
		
		@GetMapping("/get/{customerId}")
		public Customer getProductById(@PathVariable int productId) {
			return customerService.getCustomerById(productId);
		}
		
		@GetMapping("/get/cust-prod/{customerID}")
		public CustomerProductVo getCustomerWithProduct(@PathVariable int customerId) {
			return customerService.getCustomerWithProduct(customerId);
		}
		
}