package com.starhealth.product.microservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.product.microservice.entity.Product;
import com.starhealth.product.microservice.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo productRepo;
	
	public Product addProduct(Product product) {
		return productRepo.save(product);
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return productRepo.findById(productId).orElse(new Product());
	}

}
