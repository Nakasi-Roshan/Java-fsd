package com.starhealth.product.microservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.product.microservice.entity.Product;

public interface ProductRepo extends JpaRepository<Product,Integer>{

}
