package com.starhealth.product.microservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name="product_info")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int productId;
	
	String productName;
	

}
