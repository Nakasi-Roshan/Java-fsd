package com.starhealth.product.microservice.service;



import com.starhealth.product.microservice.entity.Product;


public interface ProductService {
	
	
	public Product addProduct(Product product) ;
	
	public Product getProductById(int productId);
		

}
