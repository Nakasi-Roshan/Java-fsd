package com.starhealth.excep.demo;

import java.util.Scanner;

public class AtmExcep {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int pinNum[] = { 9111, 2222, 3333, 4444, 5555 };

		int pin = sc.nextInt();

		int length = pinNum.length;

		for (int i = 0; i < length; i++) {

			if (pinNum[i] == pin) {

				System.out.println("Pin found");
				
			} else {

				try {

					throw new WrongPinException("Wrong Pin !!!");

				}

				catch (WrongPinException w) {

					System.err.println("Please Enter Valid PIN !!");
					System.out.println(w);

				}
			}

		}

	}

}
