package com.starhealth.excep.demo;

public class WrongPinException extends Exception {
	
	public WrongPinException(String w) {
		
		
	super(w);
	
	}

}
