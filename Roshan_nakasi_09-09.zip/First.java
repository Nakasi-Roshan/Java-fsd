package learning;

public class First {
	
	

	public static void main(String[] args) {
		
		int numb = 22;
		byte id = 1;
		short marks = 5;
		double score = 45.0;
		long rank = 46000;
		float totalMarks= 50.5f;
		char letter = 'A';
		boolean value = false;
		
		String studentName = "Roshan";
		
		System.out.println(numb);
		System.out.println(id);
		System.out.println(marks);
		System.out.println(score);
		System.out.println(rank);
		System.out.println(totalMarks);
		System.out.println(letter);
		System.out.println(value);
		System.out.println(studentName);

	}

}
