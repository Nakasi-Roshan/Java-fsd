package com.starhealth.collections;

import java.util.HashSet;
import java.util.Set;

public class HashSetDemo {
	
	public static void main(String[] args) {
		
		Set <Customer> obj = new HashSet<Customer>();
		
		Set<Integer> obj2 = new HashSet<Integer>();
		
		obj2.add(10);
		obj2.add(11);
		obj2.add(12);
		obj2.add(10);
		obj2.add(12);
		
		System.out.println(obj2);
		
		
		
		obj.add(new Customer(1,"Aanand",1000));
		obj.add(new Customer(2,"Roshan",2000));
		obj.add(new Customer(3,"Jashwanth",1000));
		obj.add(new Customer(1,"Raman",1000));
		
		System.out.println(obj);
		
		
		
	}

}
