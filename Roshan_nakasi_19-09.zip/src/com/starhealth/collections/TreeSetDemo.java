package com.starhealth.collections;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {
	
	public static void main(String[] args) {
		
		Set <Integer> obj9 = new TreeSet<Integer>();
		
		obj9.add(11);
		obj9.add(13);
		obj9.add(15);
		obj9.add(12);
		obj9.add(14);
		
		System.out.println(obj9);
		
		Set<Customer> obj10 = new TreeSet<Customer>(new MyComp());
		
		obj10.add(new Customer(1,"Aanand",2000));
		obj10.add(new Customer(2,"Chowdary",3000));
		obj10.add(new Customer(4,"Roshan",5000));
		obj10.add(new Customer(3,"Jash",1000));
		obj10.add(new Customer(5,"Tamiz",6000));
		
		System.out.println(obj10);
		
		
	
	}

}
