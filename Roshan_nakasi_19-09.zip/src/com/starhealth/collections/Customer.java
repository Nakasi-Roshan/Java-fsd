package com.starhealth.collections;

import java.util.Objects;

public class Customer {
	
	private int CusNumber;
	
	private String CusName;
	
	private int CusAmount;
	
	public Customer() {
		
	}

	public Customer(int cusNumber, String cusName, int cusAmount) {
		super();
		CusNumber = cusNumber;
		CusName = cusName;
		CusAmount = cusAmount;
	}

	public int getCusNumber() {
		return CusNumber;
	}

	public void setCusNumber(int cusNumber) {
		CusNumber = cusNumber;
	}

	public String getCusName() {
		return CusName;
	}

	public void setCusName(String cusName) {
		CusName = cusName;
	}

	public int getCusAmount() {
		return CusAmount;
	}

	public void setCusAmount(int cusAmount) {
		CusAmount = cusAmount;
	}

	@Override
	public String toString() {
		return "Customer [CusNumber=" + CusNumber + ", CusName=" + CusName + ", CusAmount=" + CusAmount + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(CusNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return CusNumber == other.CusNumber;
	}
	

}
