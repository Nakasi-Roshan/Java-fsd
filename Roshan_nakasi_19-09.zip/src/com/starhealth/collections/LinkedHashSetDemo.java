package com.starhealth.collections;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo {

	public static void main(String[] args) {

		Set<Integer> ok = new LinkedHashSet<Integer>();

		ok.add(12);
		ok.add(10);
		ok.add(14);
		ok.add(10);
		ok.add(15);

		System.out.println(ok);

		Set<Customer> ok2 = new LinkedHashSet<Customer>();

		ok2.add(new Customer(10, "Arjun", 2000));
		ok2.add(new Customer(11, "Reddyy", 3000));
		ok2.add(new Customer(10, "Arjun", 2000));
		ok2.add(new Customer(12, "Nag", 3000));
		ok2.add(new Customer(13, "Venky", 4000));
		
		System.out.println(ok2);
		
		Set<String> ok3 = new LinkedHashSet<String>();

		ok3.add("Apple");
		ok3.add("Banana");
		ok3.add("Apple");
		ok3.add("Orange");
		ok3.add("Grapes");

		System.out.println(ok3);

	}

}
