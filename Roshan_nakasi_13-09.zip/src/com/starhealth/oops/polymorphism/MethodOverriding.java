package com.starhealth.oops.polymorphism;

public class MethodOverriding {
	
	public void show() {
		
		System.out.println("I am from Method Overriding Class");
	}

	
	public String Mes() {
		
		return "I am not changed";
	}
	
	
}
