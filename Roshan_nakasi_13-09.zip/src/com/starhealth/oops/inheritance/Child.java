package com.starhealth.oops.inheritance;

public class Child extends Parent{
	
	
	
	public void methodTwo() {
		
		System.out.println(bikeName);
	}
	
	
	

}
