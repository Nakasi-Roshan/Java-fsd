package com.starhealth.oops.abstraction;

public interface IceBank {
	
	void deposit();
	
	void withdraw();
}
