package com.starhealth.oops.abstraction;

public class UtilBank {
	
	public static IceBank getObject(){
		
		return new ImpTwo();
		
		
		
	}

}
